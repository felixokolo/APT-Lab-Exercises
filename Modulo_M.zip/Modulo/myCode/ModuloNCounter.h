/*
 * ModuloNCounter.h
 *
 *  Created on: 3 Nov 2023
 *      Author: FELIX WORKSTATION
 */

#ifndef MODULONCOUNTER_H_
#define MODULONCOUNTER_H_

class ModuloNCounter
{
private:
public:
	ModuloNCounter();
	virtual ~ModuloNCounter();
};

#endif /* MODULONCOUNTER_H_ */
