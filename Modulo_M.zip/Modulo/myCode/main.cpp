// Standard (system) header files
#include <iostream>
#include <cstdlib>
// Add more standard header files as required
// #include <string>

using namespace std;

// Add your project's header files here
// #include "CFraction.h"
#include "ModuloNDigit.h"

// Main program
int main ()
{
    // TODO: Add your program code here
	cout << "Modulo started." << endl << endl;
	ModuloNDigit m1(5);
	ModuloNDigit m2(5);
	ModuloNDigit m3(5);
	cout << "m1 printing pre" << endl;
	for( int index = 0; index < 15; index++)
	{
		//++m1;
		m3 = m1++;
		cout << ++m3 << endl;
	}

	cout << "m2 printing post" << endl;
	for( int index = 0; index < 15; index++)
	{
		m3 = m2++;
		cout << m3 << endl;
		//cout << m2++ << endl; (check hy its not working)
	}



	return 0;
}
