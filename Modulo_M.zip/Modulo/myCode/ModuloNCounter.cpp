/*
 * ModuloNCounter.cpp
 *
 *  Created on: 3 Nov 2023
 *      Author: FELIX WORKSTATION
 */

#include "ModuloNCounter.h"

ModuloNCounter::ModuloNCounter()
{
	// TODO Auto-generated constructor stub

}

ModuloNCounter::~ModuloNCounter()
{
	// TODO Auto-generated destructor stub
}

