/*
 * ModuloNDigit.h
 *
 *  Created on: 3 Nov 2023
 *      Author: FELIX WORKSTATION
 */

#ifndef MODULONDIGIT_H_
#define MODULONDIGIT_H_
#include<iostream>
using namespace std;

#define MaxCountVal 20
/**
 * This class implements a modulo class and its required methods for operation
 */
class ModuloNDigit
{
private:
	/**< It represents the current count value   */
	unsigned int currentCount;
	/**< It represents the maximum count value n   */
	unsigned int maxCount;

public:
	/**
	 * Constructor initializes the data member
	 * @param maxCount: It represents the maximum count value n
	 */
	ModuloNDigit(unsigned int maxCount);

	/**
	 * Overload the pre-increment of Modulo.
	 * @return the object with an increase of one.
	 */
	ModuloNDigit& operator ++();

	/**
	 * Overload the post-increment of Modulo.
	 * @return the previous value of the object.
	 */
	ModuloNDigit operator ++(int);
	friend ostream& operator << (ostream& out, ModuloNDigit& m);
};

#endif /* MODULONDIGIT_H_ */
