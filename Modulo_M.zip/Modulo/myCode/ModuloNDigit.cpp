/*
 * ModuloNDigit.cpp
 *
 *  Created on: 3 Nov 2023
 *      Author: FELIX WORKSTATION
 */

#include "ModuloNDigit.h"



ModuloNDigit::ModuloNDigit( unsigned int maxCount)
{
	this->currentCount = 0;
	if(maxCount <= 0 || maxCount > MaxCountVal)
	{
		cout <<"invalid number" << endl;
		this->maxCount = MaxCountVal;
	}
	else
	{
		this->maxCount = maxCount;

	}


}

ModuloNDigit& ModuloNDigit::operator ++()
{
	this->currentCount += 1;
	//this->currentCount = this->currentCount % this->maxCount;

	if(this->currentCount % this->maxCount == 0)
	{
		this->currentCount = 0;
	}
	else
	{
		// do nothing
	}

	return *this;
}

ModuloNDigit ModuloNDigit::operator ++(int int1)
{
	ModuloNDigit result(this->maxCount);
	result= *this;
	operator ++();
	return result;
}

ostream& operator << (ostream& out, ModuloNDigit& m)
{
	if(m.currentCount < 10)
	{
		out << "current value: " << m.currentCount << " max value: " <<m.maxCount<< endl;
	}
	else
	{
		out << "current value: " <<(char)m.currentCount << " max value: " <<m.maxCount<< endl;
	}

	return out;

}
