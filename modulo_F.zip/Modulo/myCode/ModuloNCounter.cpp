/*
 * ModuloNCounter.cpp
 *
 *  Created on: 03.11.2023
 *      Author: acer
 */

#include "ModuloNCounter.h"

ModuloNCounter::ModuloNCounter()
{
	// TODO Auto-generated constructor stub

}

ModuloNCounter::~ModuloNCounter()
{
	// TODO Auto-generated destructor stub
}

