/*
 * ModuloNCounter.h
 *
 *  Created on: 03.11.2023
 *      Author: acer
 */

#ifndef MODULONCOUNTER_H_
#define MODULONCOUNTER_H_

class ModuloNCounter
{
public:
	ModuloNCounter();
	virtual ~ModuloNCounter();
};

#endif /* MODULONCOUNTER_H_ */
