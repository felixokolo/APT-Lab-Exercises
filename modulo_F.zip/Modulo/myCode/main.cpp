// Standard (system) header files
#include <iostream>
#include <cstdlib>
using namespace std;

#include "ModuloNDigit.h"


// Main program
int main ()
{
	ModuloNDigit m1(16);
	for (int c = 0; c < 20; c++)
	{
		++m1;
		cout << m1 << endl;
	}


	return 0;
}
