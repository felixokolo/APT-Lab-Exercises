/*
 * ModuloNDigit.h
 *
 *  Created on: 03.11.2023
 *      Author: Felix
 */

#ifndef MODULONDIGIT_H_
#define MODULONDIGIT_H_

#define MAX_COUNT 16 /**< Maximum possible value for maxValue. */
#define MIN_COUNT 2 /**< Minimum possible value for maxValue. */

class ModuloNDigit
{
private:
	unsigned int currentValue;
	/**< Holds the current value of the ModuloNDigit counter object. */

	unsigned int maxValue;
	/**< Holds the maximum value of the ModuloNDigit counter object*/

public:
	/**
	 * Default constructor for the ModuloNDigit object.
	 * Initializes the currentValue to 0.
	 * @param [in] maxValue Holds the maximum value of the ModuloNDigit
	 * counter object.
	 */
	ModuloNDigit(unsigned int maxValue);

	/**
	 * Overloaded pre-increment operator.
	 * @return An object by reference with the currentValue
	 * incremented or reset to 0.
	 */
	ModuloNDigit& operator++();

	/**
	 * Overloaded pre-increment operator.
	 * @param [in] c Pseudo input parameter.
	 * @return An object with the currentValue
	 * not incremented or reset to 0.
	 */
	ModuloNDigit operator++(int c);

	/**
	 * Overloaded output << operator function.
	 */
	friend std::ostream& operator<<(std::ostream& out, ModuloNDigit& counter);

	/**
	 * Prints the counter value in a specified format.
	 */
	void print();


};

#endif /* MODULONDIGIT_H_ */
