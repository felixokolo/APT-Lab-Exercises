/**
 * \mainpage
 * ModuloNDigit.cpp
 *
 *  Created on: 03.11.2023
 *      Author: acer
 *
 *  This class implements a Digit counter that counts up to a
 *  specified maxValue.
 *  It only counts in digits with a maximum digit count of MAX_COUNT of 16
 *  and a minimum digit count of 2.
 *  This class can be used to implement base numbers counting with the base
 *  value represented as maxValue. E.g a maxValue of 2 represents the base 2
 *  number system.
 *
 *  Usage
 *  ModuloNDigit m1(3); // Creates an instance of ModuloNDigit.
 *  m++; // Post-increment for the counter.
 *  cout << m1 << endl; // Prints the currentValue of the counter.
 */

#include <iostream>
using namespace std;

#include "ModuloNDigit.h"


ModuloNDigit::ModuloNDigit(unsigned int maxValue)
{
	//Checks if maxValue is greater than the maximum count MAX_COUNT
	if (maxValue > MAX_COUNT)
		maxValue = MAX_COUNT;

	//Checks if maxValue is greater than the minimum count MIN_COUNT
	if (maxValue < MIN_COUNT)
		maxValue = MIN_COUNT;
	this->currentValue = 0;
	this->maxValue = maxValue;
}

ModuloNDigit& ModuloNDigit::operator ++()
{
	// Checks if currentValue is at max - 1
	this->currentValue == this->maxValue - 1?
			this->currentValue = 0 : // Resets to 0
			this->currentValue += 1; // Increments the currentValue by 1
	return *this;
}

ModuloNDigit ModuloNDigit::operator ++(int c)
{
	ModuloNDigit tmp(this->maxValue);
	tmp = *this;
	this->operator ++();
	return tmp;
}

void ModuloNDigit::print()
{
	this->currentValue < 10?
			cout << this->currentValue :
			cout << char('A' + (10 % this->currentValue));
}

ostream& operator<<(ostream& out, ModuloNDigit& counter)
{
	counter.currentValue < 10?
				cout << counter.currentValue :
				cout << char('A' + (counter.currentValue % 10));
	return out;
}


